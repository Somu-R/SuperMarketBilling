package com.smb.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.smb.entity.AdminEntity;
import com.smb.model.Admin;
@Repository(value="AdminDAO")
public class AdminDAOImpl implements AdminDAO{
	@PersistenceContext
	EntityManager entityManager;
	public Admin getAdmin(Integer Aid) throws Exception {
		Admin admin=null;
		AdminEntity a=entityManager.find(AdminEntity.class, Aid);
		if(a!=null) {
			admin = new Admin();
			admin.setAid(a.getAid());
			admin.setName(a.getName());
			admin.setPassword(a.getPassword());
		}
		return admin;
	}

}
