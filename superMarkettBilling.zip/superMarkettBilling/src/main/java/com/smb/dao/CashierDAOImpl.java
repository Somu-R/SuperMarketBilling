package com.smb.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.smb.entity.CashierEntity;
import com.smb.model.Cashier;


@Repository(value="cashierDAO")
public class CashierDAOImpl implements CashierDAO {
	@PersistenceContext
	EntityManager entityManager;
	
	public Integer addCashier(Cashier cashier) throws Exception {
		Integer cidOut=null;
		
		CashierEntity ce=new CashierEntity();
		ce.setCid(cashier.getCid());
		ce.setName(cashier.getName());
		ce.setMobileno(cashier.getMobileno());
		ce.setAddress(cashier.getAddress());
		ce.setEmailid(cashier.getEmailid());
		ce.setPassword(cashier.getPassword());
		cidOut=ce.getCid();
		entityManager.persist(ce);
		return cidOut;
				
				
	}

	public Cashier getCashier(Integer cid) throws Exception {
		Cashier cashier=null;
		CashierEntity cashierEntity=entityManager.find(CashierEntity.class, cid);
		if(cashierEntity!=null) {
			cashier =new Cashier();
			cashier.setCid(cashierEntity.getCid());
			cashier.setName(cashierEntity.getName());
			cashier.setPassword(cashierEntity.getPassword());
			cashier.setAddress(cashierEntity.getAddress());
			cashier.setMobileno(cashierEntity.getMobileno());
			cashier.setEmailid(cashierEntity.getEmailid());
			
		}
		return cashier;
	
	}

	public String updateCashier(Integer CashierID,String CashierName,Integer MobileNumber,String Address,String EmailID,String Password) throws Exception {
		String out=null;
		CashierEntity cashierEntity=entityManager.find(CashierEntity.class, CashierID);
		if(cashierEntity!=null) {
			cashierEntity.setPassword(Password);
			cashierEntity.setAddress(Address);
			cashierEntity.setEmailid(EmailID);
			cashierEntity.setMobileno(MobileNumber);
			cashierEntity.setName(CashierName);
			out="success";
		}
		return out;
	}

	public String deleteCashier(Integer cid) throws Exception {
		String out=null;
		CashierEntity cashierEntity=entityManager.find(CashierEntity.class, cid);
		if(cashierEntity!=null) {
			entityManager.remove(cashierEntity);
			}
		return out;
	}

}
