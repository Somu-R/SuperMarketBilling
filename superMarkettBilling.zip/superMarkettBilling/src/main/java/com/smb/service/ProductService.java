package com.smb.service;

import com.smb.model.Product;

public interface ProductService {
	public String addProduct(Product product) throws Exception;
	public Product getProduct(Integer pId) throws Exception;
	public String updateStock(Integer pId,Integer quantity)throws Exception;
}
