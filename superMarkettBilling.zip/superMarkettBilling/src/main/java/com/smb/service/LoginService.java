package com.smb.service;



public interface LoginService {
	public int verifyadmin();
	public int verifyCashier();
	public String authAdmin(Integer aId,String pass);
	public String authCashier(Integer CId,String pass);
}
