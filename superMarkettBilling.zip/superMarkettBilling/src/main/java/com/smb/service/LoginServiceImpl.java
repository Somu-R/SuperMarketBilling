package com.smb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smb.dao.AdminDAO;
import com.smb.dao.CashierDAO;
import com.smb.model.Admin;
import com.smb.model.Cashier;
@Service(value = "loginServiceImpl")
@Transactional
public class LoginServiceImpl implements LoginService {
	@Autowired
	AdminDAO adminDAO;
	@Autowired
	CashierDAO cashierDAO;
	public int admin_flag=0;
	public int cashier_flag=0;
	public String authAdmin(Integer aId,String pass) {
	
		try {
			
			Admin a=adminDAO.getAdmin(aId);
			
			//System.out.println(a.getAid()+" "+a.getPassword());
			if(a.getPassword().equals(pass)) {
				admin_flag=1;
				return new String("success");
			}
			else {
				return new String("failed");
			}
		}
		catch (Exception e) {
			return new String("error");
		}
	}
	@Override
	public String authCashier(Integer CId, String pass) {
		try {
			Cashier c=cashierDAO.getCashier(CId);
			if(c.getPassword().equals(pass)) {
				cashier_flag=1;
				return new String("success");
				
			}
			else {
				return new String("failed");
			}
		}
		catch (Exception e) {
			return new String("error");
		}
	}
	@Override
	public int verifyadmin() {
		return admin_flag;
	}
	@Override
	public int verifyCashier() {
		
		return cashier_flag;
	}

}
